/*
-- Query: SELECT * FROM bms.student
LIMIT 0, 1000

-- Date: 2019-09-05 02:26
*/
INSERT INTO `` (`stdNum`,`stdName`,`stdGrade`,`stdMajor`,`stdPw`,`stdPhone`) VALUES ('10001','윤수현','3','영어영문학','1001','0101111');
INSERT INTO `` (`stdNum`,`stdName`,`stdGrade`,`stdMajor`,`stdPw`,`stdPhone`) VALUES ('10002','강감찬','2','컴퓨터공학','1002','0102222');
INSERT INTO `` (`stdNum`,`stdName`,`stdGrade`,`stdMajor`,`stdPw`,`stdPhone`) VALUES ('10003','김좌진','4','컴퓨터공학','1003','0103333');
INSERT INTO `` (`stdNum`,`stdName`,`stdGrade`,`stdMajor`,`stdPw`,`stdPhone`) VALUES ('10004','갈길가','1','국어국문학','1004','0104444');
INSERT INTO `` (`stdNum`,`stdName`,`stdGrade`,`stdMajor`,`stdPw`,`stdPhone`) VALUES ('10005','가지마','4','컴퓨터공학','1005','0105555');
INSERT INTO `` (`stdNum`,`stdName`,`stdGrade`,`stdMajor`,`stdPw`,`stdPhone`) VALUES ('10009','요기요','1','순수물리학','1009','0109876');
