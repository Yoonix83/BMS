/*
-- Query: SELECT * FROM bms.course
LIMIT 0, 1000

-- Date: 2019-09-05 02:01
*/
INSERT INTO `` (`crsNum`,`crsName`,`crsCredit`,`crsMajor`,`proNum`,`proName`) VALUES ('A0001','JAVA','3','컴퓨터공학','20001','강미나');
INSERT INTO `` (`crsNum`,`crsName`,`crsCredit`,`crsMajor`,`proNum`,`proName`) VALUES ('A0002','SPRING','3','컴퓨터공학','20002','김나비');
INSERT INTO `` (`crsNum`,`crsName`,`crsCredit`,`crsMajor`,`proNum`,`proName`) VALUES ('B0001','스피킹','2','영어영문학','20003','박공식');
INSERT INTO `` (`crsNum`,`crsName`,`crsCredit`,`crsMajor`,`proNum`,`proName`) VALUES ('B0002','영국사회','2','영어영문학','20005','테스트1');
INSERT INTO `` (`crsNum`,`crsName`,`crsCredit`,`crsMajor`,`proNum`,`proName`) VALUES ('B0004','미국사회','2','영어영문학','20006','테스트2');
INSERT INTO `` (`crsNum`,`crsName`,`crsCredit`,`crsMajor`,`proNum`,`proName`) VALUES ('C0001','한국사','3','국어국문학','20004','나역사');
