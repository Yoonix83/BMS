/*
-- Query: SELECT * FROM bms.major
LIMIT 0, 1000

-- Date: 2019-09-05 02:25
*/
INSERT INTO `` (`mjrNum`,`mjrName`) VALUES ('0001','컴퓨터공학');
INSERT INTO `` (`mjrNum`,`mjrName`) VALUES ('0002','영어영문학');
INSERT INTO `` (`mjrNum`,`mjrName`) VALUES ('0003','국어국문학');
INSERT INTO `` (`mjrNum`,`mjrName`) VALUES ('0004','순수물리학');
