/*
-- Query: SELECT * FROM bms.takecourse
LIMIT 0, 1000

-- Date: 2019-09-05 02:26
*/
INSERT INTO `` (`tk_stdNum`,`tkMark`,`tk_crsNum`,`tk_crsName`) VALUES ('10001',NULL,'B0002','영국사회');
INSERT INTO `` (`tk_stdNum`,`tkMark`,`tk_crsNum`,`tk_crsName`) VALUES ('10001',NULL,'B0004','미국사회');
INSERT INTO `` (`tk_stdNum`,`tkMark`,`tk_crsNum`,`tk_crsName`) VALUES ('10001',NULL,'C0001','한국사');
INSERT INTO `` (`tk_stdNum`,`tkMark`,`tk_crsNum`,`tk_crsName`) VALUES ('10002','A','A0001','JAVA');
INSERT INTO `` (`tk_stdNum`,`tkMark`,`tk_crsNum`,`tk_crsName`) VALUES ('10002','B','A0002','Spring');
INSERT INTO `` (`tk_stdNum`,`tkMark`,`tk_crsNum`,`tk_crsName`) VALUES ('10003','A+','A0002','Spring');
INSERT INTO `` (`tk_stdNum`,`tkMark`,`tk_crsNum`,`tk_crsName`) VALUES ('10005','C+','A0001','JAVA');
