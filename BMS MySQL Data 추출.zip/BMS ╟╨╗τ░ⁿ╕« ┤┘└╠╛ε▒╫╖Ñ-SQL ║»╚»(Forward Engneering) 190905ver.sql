-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema bms
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema bms
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `bms` DEFAULT CHARACTER SET utf8 ;
USE `bms` ;

-- -----------------------------------------------------
-- Table `bms`.`major`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bms`.`major` (
  `mjrNum` VARCHAR(45) NOT NULL,
  `mjrName` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`mjrName`),
  UNIQUE INDEX `mjrNum_UNIQUE` (`mjrNum` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bms`.`professor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bms`.`professor` (
  `proNum` VARCHAR(45) NOT NULL,
  `proName` VARCHAR(45) NOT NULL,
  `proGrade` VARCHAR(45) NOT NULL,
  `proMajor` VARCHAR(45) NOT NULL,
  `proPw` VARCHAR(45) NOT NULL,
  `proPhone` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`proNum`),
  INDEX `fk_Professor_Major1_idx` (`proMajor` ASC),
  CONSTRAINT `fk_Professor_Major1`
    FOREIGN KEY (`proMajor`)
    REFERENCES `bms`.`major` (`mjrName`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bms`.`course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bms`.`course` (
  `crsNum` VARCHAR(45) NOT NULL,
  `crsName` VARCHAR(45) NOT NULL,
  `crsCredit` VARCHAR(45) NOT NULL,
  `crsMajor` VARCHAR(45) NOT NULL,
  `proNum` VARCHAR(45) NOT NULL,
  `proName` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`crsNum`),
  UNIQUE INDEX `crsName_UNIQUE` (`crsName` ASC),
  INDEX `fk_Course_Professor1_idx` (`proNum` ASC),
  INDEX `fk_Course_Major1_idx` (`crsMajor` ASC),
  CONSTRAINT `fk_Course_Major1`
    FOREIGN KEY (`crsMajor`)
    REFERENCES `bms`.`major` (`mjrName`),
  CONSTRAINT `fk_Course_Professor1`
    FOREIGN KEY (`proNum`)
    REFERENCES `bms`.`professor` (`proNum`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bms`.`employee`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bms`.`employee` (
  `empNum` VARCHAR(45) NOT NULL,
  `empName` VARCHAR(45) NOT NULL,
  `empDpt` VARCHAR(45) NOT NULL,
  `empMgr` VARCHAR(45) NOT NULL,
  `empPw` VARCHAR(45) NOT NULL,
  `empPhone` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`empNum`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bms`.`student`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bms`.`student` (
  `stdNum` VARCHAR(45) NOT NULL,
  `stdName` VARCHAR(45) NOT NULL,
  `stdGrade` VARCHAR(45) NOT NULL,
  `stdMajor` VARCHAR(45) NOT NULL,
  `stdPw` VARCHAR(45) NOT NULL,
  `stdPhone` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`stdNum`),
  INDEX `fk_Student_Major1` (`stdMajor` ASC),
  CONSTRAINT `fk_Student_Major1`
    FOREIGN KEY (`stdMajor`)
    REFERENCES `bms`.`major` (`mjrName`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bms`.`takecourse`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bms`.`takecourse` (
  `tk_stdNum` VARCHAR(45) NOT NULL,
  `tkMark` VARCHAR(45) NULL DEFAULT NULL,
  `tk_crsNum` VARCHAR(45) NOT NULL,
  `tk_crsName` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`tk_stdNum`, `tk_crsNum`),
  INDEX `fk_TakeCourse_Student_idx` (`tk_stdNum` ASC),
  INDEX `fk_TakeCourse_crsNum_idx` (`tk_crsNum` ASC),
  INDEX `fk_TakeCourse_crsName_idx` (`tk_crsName` ASC),
  CONSTRAINT `fk_TakeCourse_Student`
    FOREIGN KEY (`tk_stdNum`)
    REFERENCES `bms`.`student` (`stdNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_TakeCourse_crsName`
    FOREIGN KEY (`tk_crsName`)
    REFERENCES `bms`.`course` (`crsName`),
  CONSTRAINT `fk_TakeCourse_crsNum`
    FOREIGN KEY (`tk_crsNum`)
    REFERENCES `bms`.`course` (`crsNum`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
