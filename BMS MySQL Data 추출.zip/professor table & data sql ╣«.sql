/*
-- Query: SELECT * FROM bms.professor
LIMIT 0, 1000

-- Date: 2019-09-05 02:25
*/
INSERT INTO `` (`proNum`,`proName`,`proGrade`,`proMajor`,`proPw`,`proPhone`) VALUES ('20001','강미나','정교수','컴퓨터공학','2001','0101010');
INSERT INTO `` (`proNum`,`proName`,`proGrade`,`proMajor`,`proPw`,`proPhone`) VALUES ('20002','김나비','부교수','컴퓨터공학','2002','0102020');
INSERT INTO `` (`proNum`,`proName`,`proGrade`,`proMajor`,`proPw`,`proPhone`) VALUES ('20003','박공식','정교수','영어영문학','2003','0103030');
INSERT INTO `` (`proNum`,`proName`,`proGrade`,`proMajor`,`proPw`,`proPhone`) VALUES ('20004','나역사','계약직','국어국문학','2004','0104040');
INSERT INTO `` (`proNum`,`proName`,`proGrade`,`proMajor`,`proPw`,`proPhone`) VALUES ('20005','테스트1','정교수','영어영문학','2005','0105050');
INSERT INTO `` (`proNum`,`proName`,`proGrade`,`proMajor`,`proPw`,`proPhone`) VALUES ('20006','테스트2','부교수','영어영문학','2006','0106060');
